package model;

import java.math.BigDecimal;

public class OrcamentoProxy extends Orcamento {

    private BigDecimal descontoOrcamento;

    private Orcamento orcamento;    

    public OrcamentoProxy(Orcamento orcamento) {
        this.orcamento = orcamento;
    }

    public void setDescontoOrcamento(BigDecimal descontoOrcamento) {
        this.descontoOrcamento = descontoOrcamento;
    }

    public BigDecimal getdescontoOrcamento() {
        if (descontoOrcamento == null) {
            this.descontoOrcamento = orcamento.getDescontoOrcamento();
        }
        return descontoOrcamento;
    }
}
