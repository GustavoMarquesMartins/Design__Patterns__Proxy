package model;

import java.math.BigDecimal;

public class Orcamento {

    private BigDecimal valorOrcamento;

    private BigDecimal descontoOrcamento;

    public Orcamento(BigDecimal valorOrcamento, BigDecimal descontoOrcamento) {
        this.valorOrcamento = valorOrcamento;
        this.descontoOrcamento = descontoOrcamento;
    }

    public Orcamento() {
    }

    public BigDecimal getValorOrcamento() {
        return valorOrcamento;
    }

    public void setValorOrcamento(BigDecimal valorOrcamento) {
        this.valorOrcamento = valorOrcamento;
    }

    public void setDescontoOrcamento(BigDecimal descontoOrcamento) {
        this.descontoOrcamento = descontoOrcamento;
    }

    public BigDecimal getDescontoOrcamento() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException erro) {
            throw new RuntimeException(erro);

        }
        return descontoOrcamento;
    }

}
